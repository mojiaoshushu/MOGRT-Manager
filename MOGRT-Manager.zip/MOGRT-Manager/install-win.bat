@echo off
setlocal enabledelayedexpansion

echo ================================================
echo   MOGRT Manager - Windows Installer
echo ================================================
echo.

set "EXT_NAME=com.mogrt.manager"
set "EXT_DIR=C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\%EXT_NAME%"
set "SRC_DIR=%~dp0"

echo [1/3] Enabling CEP debug mode...
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
echo    CEP debug mode enabled.

echo [2/3] Installing extension files...
if exist "%EXT_DIR%" (
    rd /s /q "%EXT_DIR%"
)
md "%EXT_DIR%" >nul 2>&1
md "%EXT_DIR%\CSXS" >nul 2>&1
md "%EXT_DIR%\client" >nul 2>&1
md "%EXT_DIR%\host" >nul 2>&1
md "%EXT_DIR%\lib" >nul 2>&1
md "%EXT_DIR%\icons" >nul 2>&1

copy /y "%SRC_DIR%CSXS\manifest.xml" "%EXT_DIR%\CSXS\manifest.xml" >nul 2>&1
copy /y "%SRC_DIR%client\index.html" "%EXT_DIR%\client\index.html" >nul 2>&1
copy /y "%SRC_DIR%host\index.jsx" "%EXT_DIR%\host\index.jsx" >nul 2>&1
copy /y "%SRC_DIR%lib\CSInterface.js" "%EXT_DIR%\lib\CSInterface.js" >nul 2>&1
copy /y "%SRC_DIR%icons\icon-dark.png" "%EXT_DIR%\icons\icon-dark.png" >nul 2>&1
copy /y "%SRC_DIR%icons\icon-light.png" "%EXT_DIR%\icons\icon-light.png" >nul 2>&1
if exist "%SRC_DIR%.debug" (
    copy /y "%SRC_DIR%.debug" "%EXT_DIR%\.debug" >nul 2>&1
)
echo    Extension files installed.

echo [3/3] Installation complete!
echo.
echo ================================================
echo   Please restart Premiere Pro, then go to:
echo   Window ^> Extensions (Legacy) ^> MOGRT Manager
echo ================================================
echo.

endlocal
pause
