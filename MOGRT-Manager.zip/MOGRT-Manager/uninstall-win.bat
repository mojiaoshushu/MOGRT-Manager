@echo off
setlocal

echo ================================================
echo   MOGRT Manager - Windows Uninstaller
echo ================================================
echo.

set "EXT_DIR=C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\com.mogrt.manager"

if exist "%EXT_DIR%" (
    rd /s /q "%EXT_DIR%"
    echo    Extension removed successfully.
) else (
    echo    Extension folder not found.
)

echo.
echo    Please restart Premiere Pro to complete.
echo.

endlocal
pause
