#!/bin/bash
echo "================================================"
echo "  MOGRT Manager - macOS Installer"
echo "================================================"
echo ""

EXT_DIR="/Library/Application Support/Adobe/CEP/extensions/com.mogrt.manager"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[1/3] Enabling CEP debug mode..."
defaults write com.adobe.CSXS.12 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.11 PlayerDebugMode 1 2>/dev/null
defaults write com.adobe.CSXS.10 PlayerDebugMode 1 2>/dev/null
echo "   Done."

echo "[2/3] Installing extension files..."
sudo rm -rf "$EXT_DIR"
sudo mkdir -p "$EXT_DIR"
sudo cp -R "$SCRIPT_DIR/CSXS" "$EXT_DIR/"
sudo cp -R "$SCRIPT_DIR/client" "$EXT_DIR/"
sudo cp -R "$SCRIPT_DIR/host" "$EXT_DIR/"
sudo cp -R "$SCRIPT_DIR/lib" "$EXT_DIR/"
sudo cp -R "$SCRIPT_DIR/icons" "$EXT_DIR/"
if [ -f "$SCRIPT_DIR/.debug" ]; then
    sudo cp "$SCRIPT_DIR/.debug" "$EXT_DIR/"
fi
sudo chmod -R 755 "$EXT_DIR"
echo "   Done."

echo "[3/3] Installation complete!"
echo ""
echo "================================================"
echo "  Please restart Premiere Pro, then go to:"
echo "  Window > Extensions (Legacy) > MOGRT Manager"
echo "================================================"
