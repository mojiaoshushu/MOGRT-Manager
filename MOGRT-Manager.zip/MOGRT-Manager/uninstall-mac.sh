#!/bin/bash
echo "================================================"
echo "  MOGRT Manager - macOS Uninstaller"
echo "================================================"
echo ""

EXT_DIR="/Library/Application Support/Adobe/CEP/extensions/com.mogrt.manager"

echo "[1/3] Removing extension files..."
if [ -d "$EXT_DIR" ]; then
    sudo rm -rf "$EXT_DIR"
    echo "   Done."
else
    echo "   Extension not found, skipping."
fi

echo "[2/3] Disabling CEP debug mode..."
defaults delete com.adobe.CSXS.12 PlayerDebugMode 2>/dev/null
defaults delete com.adobe.CSXS.11 PlayerDebugMode 2>/dev/null
defaults delete com.adobe.CSXS.10 PlayerDebugMode 2>/dev/null
echo "   Done."

echo "[3/3] Uninstallation complete!"
echo ""
echo "================================================"
echo "  MOGRT Manager has been removed."
echo "  Please restart Premiere Pro to apply changes."
echo "================================================"
